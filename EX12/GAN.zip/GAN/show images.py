import pickle
import matplotlib.pyplot as plt

# 训练迭代轮数
epochs = 300

with open('train_samples1.pkl', 'rb') as f:
    samples = pickle.load(f)

# 指定要查看的轮次
epoch_idx = [0, 5, 10, 20, 40, 60, 80, 100, 150, 250, 300, 340]  # 一共350轮，不要越界
show_imgs = []
for i in epoch_idx:
    show_imgs.append(samples[i][1])

# 指定图片形状
# rows, cols = 10, 25
rows, cols = 12, 25
fig, axes = plt.subplots(figsize=(30, 12), nrows=rows, ncols=cols, sharex=True, sharey=True)
# figsize来设置窗口的尺寸大小， rows行数，ncols列数

for sample, ax_row in zip(show_imgs, axes):
    for img, ax in zip(sample[::int(len(sample) / cols)], ax_row):
        ax.imshow(img.reshape((28, 28)), cmap='Greys_r')
        ax.xaxis.set_visible(False)
        ax.yaxis.set_visible(False)

plt.show()

