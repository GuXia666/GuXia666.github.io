import numpy as np
import matplotlib.pyplot as plt


losses = np.load('losses.npy')  # 读取losses矩阵

#    绘制loss曲线

fig, ax = plt.subplots(figsize=(20, 7))  # figsize 来设置窗口的尺寸大小，fig代表绘图窗口(Figure)；ax代表这个绘图窗口上的坐标系(axis)
plt.plot(losses.T[0], label='Discriminator Total Loss')  # 取losses的每一列画曲线,矩阵中的T操作，取某一列
plt.plot(losses.T[1], label='Discriminator Real Loss')
plt.plot(losses.T[2], label='Discriminator Fake Loss')
plt.plot(losses.T[3], label='Generator')
plt.title("Training Losses")
plt.legend()  # 在画的图中加上图例（此处为各个曲线的名称）
plt.show()



