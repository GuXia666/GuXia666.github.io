import tensorflow as tf
import numpy as np
import matplotlib.pyplot as plt



with tf.Session() as sess:
    model = tf.train.import_meta_graph('checkpoints/generator.ckpt.meta')  # 恢复计算图结构
    model.restore(sess, tf.train.latest_checkpoint("checkpoints/"))  # 恢复所有变量信息
    
    graph = tf.get_default_graph()
    sample_noise = np.random.uniform(-1, 1, size=(1, 100))
    # # 从一个均匀分布[low,high)中随机采样,此处为[-1,1），采样大小为（1，100）
    generator_out = graph.get_tensor_by_name('generator/gen_output:0')
    input_noise = graph.get_tensor_by_name('noise_img:0')
    outputs = sess.run(generator_out, feed_dict={input_noise: sample_noise})
    outputs = outputs.reshape((28, 28))
    
    plt.imshow(outputs, cmap='gray_r')
plt.show()

