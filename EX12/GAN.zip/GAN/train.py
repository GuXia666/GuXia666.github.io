import tensorflow as tf
import numpy as np
import pickle


from tensorflow.examples.tutorials.mnist import input_data

mnist = input_data.read_data_sets('./data/')
img = mnist.train.images[50]  # img 此处为mnist的train图片数据集中的第51张图片，有784个参数


def get_inputs(real_size, noise_size):
    """
    真实图像tensor与噪声图像tensor
    """
    # placeholder占位符 [None, real_size] 表示行数不定，列数为real_size的值
    real_img = tf.placeholder(tf.float32, [None, real_size], name='real_img')
    noise_img = tf.placeholder(tf.float32, [None, noise_size], name='noise_img')

    return real_img, noise_img


def get_generator(noise_img, n_units, out_dim, reuse=False, alpha=0.01):
    # 设置reuse=False时，函数get_variable（）表示创建新变量，reuse=True时，表示调用已有的变量
    """
    生成器
    noise_img: 生成器的输入
    n_units: 隐层单元个数
    out_dim: 生成器输出tensor的size，这里应该为28*28=784
    alpha: leaky ReLU系数
    """
    # 创建generator变量空间，reuse = False
    with tf.variable_scope("generator", reuse=reuse):  # tf.variable_scope()用来指定变量的作用域，作为变量名的前缀

        # hidden layer
        hidden1 = tf.layers.dense(noise_img, n_units)  # dense ：全连接层   inputs：输入该网络层的数据 units：输出的维度大小，改变inputs的最后一维
        # leaky ReLU    Leaky ReLU是给所有负值赋予一个非零斜率。
        hidden1 = tf.maximum(alpha * hidden1, hidden1)  # 返回二者较大值，因为alpha<1，所以正数时相当于返回自身，负数时返回alpha*自身，即Leaky ReLU过程
        # dropout
        hidden1 = tf.layers.dropout(hidden1, rate=0.2)  # dropout 防止过拟合，应用于输入，rate退出率   rate=0.2，输出单位将减少20%
        # logits & outputs
        logits = tf.layers.dense(hidden1, out_dim)  # 非归一化对数概率（又名logits） logits作为最后激活函数的前一层，输入到激活函数
        outputs = tf.tanh(logits, name='gen_output')  # 双曲正切函数，作用就是激活函数，值域为[-1,1]。类似于 sigmoid函数，不过sigmoid值域为[0,1]
        return logits, outputs


def get_discriminator(img, n_units, reuse=False, alpha=0.01):
    """
    判别器

    n_units: 隐层结点数量
    alpha: Leaky ReLU系数
    """
    # 创建discriminator变量空间，reuse = False
    with tf.variable_scope("discriminator", reuse=reuse):  # tf.variable_scope()用来指定变量的作用域，作为变量名的前缀

        # hidden layer
        hidden1 = tf.layers.dense(img, n_units)  # 全连接层
        hidden1 = tf.maximum(alpha * hidden1, hidden1)  # Leaky ReLU激活函数

        # logits & outputs
        logits = tf.layers.dense(hidden1, 1)
        outputs = tf.sigmoid(logits, name='output')  # sigmoid函数，值域为[0,1]

        return logits, outputs


# 定义参数
# 真实图像的size
img_size = mnist.train.images[0].shape[0]  # img_size = 784
# 传入给generator的噪声size
noise_size = 100
# 生成器隐层参数
g_units = 128
# 判别器隐层参数
d_units = 128
# leaky ReLU的参数
alpha = 0.01
# learning_rate
learning_rate = 0.001
# label smoothing   防止过拟合，smooth=0.1，范围由[0，1]->[0.05,0.95]
smooth = 0.1

tf.reset_default_graph()  # 用于清除默认图形堆栈并重置全局默认图形。

real_img, noise_img = get_inputs(img_size, noise_size)  # real_img [None, 784]      noise_img [None, 100]

# generator
g_logits, g_outputs = get_generator(noise_img, g_units, img_size)

# discriminator
d_logits_real, d_outputs_real = get_discriminator(real_img, d_units)
d_logits_fake, d_outputs_fake = get_discriminator(g_outputs, d_units, reuse=True)  # 此处reuse=True，因为两次用到discriminator
# discriminator的loss
# 识别真实图片
d_loss_real = tf.reduce_mean(tf.nn.sigmoid_cross_entropy_with_logits(logits=d_logits_real,
                                                                     labels=tf.ones_like(d_logits_real)) * (1 - smooth))

# tf.reduce_mean用于计算张量tensor沿着指定的数轴（tensor的某一维度）上的的平均值，主要用作降维或者计算tensor（图像）的平均值。 axis： 指定的轴，如果不指定，则计算所有元素的均值;
# tf.nn.sigmoid_cross_entropy_with_logits   总的损失 = 预测结果对应正确类别处的损失 + 预测结果对应错误类别处的损失
# tf.ones_like函数目的是创建一个和输入参数（tensor）维度一样，元素都为1的张量。

# 识别生成的图片
d_loss_fake = tf.reduce_mean(tf.nn.sigmoid_cross_entropy_with_logits(logits=d_logits_fake,
                                                                     labels=tf.zeros_like(d_logits_fake)))
# tf.zeros_like函数目的是创建一个和输入参数（tensor）维度一样，元素都为0的张量。

# 总体loss
d_loss = tf.add(d_loss_real, d_loss_fake)

# generator的loss
g_loss = tf.reduce_mean(tf.nn.sigmoid_cross_entropy_with_logits(logits=d_logits_fake,
                                                                labels=tf.ones_like(d_logits_fake)) * (1 - smooth))

train_vars = tf.trainable_variables()  # 返回需要训练的变量列表

# generator中的tensor
g_vars = [var for var in train_vars if var.name.startswith("generator")]  # 获取以generator开头的列表，为了在优化器中加载生成器模型
# discriminator中的tensor
d_vars = [var for var in train_vars if var.name.startswith("discriminator")]  # 获取以discriminator开头的列表，为了在优化器中加载判别器模型

# print(g_vars)
# print(d_vars)

# optimizer
d_train_opt = tf.train.AdamOptimizer(learning_rate).minimize(d_loss, var_list=d_vars)  # minimize函数用来指定最小化的目标
g_train_opt = tf.train.AdamOptimizer(learning_rate).minimize(g_loss, var_list=g_vars)

# 训练
# batch_size
batch_size = 64
# 训练迭代轮数
epochs = 350
# 抽取样本数
n_sample = 25

# 存储测试样例
samples = []
# 存储loss
losses = []
# 保存生成器变量
saver = tf.train.Saver(var_list=g_vars)
# 开始训练
with tf.Session() as sess:
    sess.run(tf.global_variables_initializer())  # 将所有图变量进行集体初始化
    for e in range(epochs):                      # 总共迭代300轮样本集
        for batch_i in range(mnist.train.num_examples // batch_size):  # mnist.train.num_examples // batch_size 迭代完一次样本集所循环的次数
            batch = mnist.train.next_batch(batch_size)  # 通过next_batch来获取下一个数据集来对我们的参数进行调整

            batch_images = batch[0].reshape((batch_size, 784))
            # 对图像像素进行scale，这是因为tanh输出的结果介于(-1,1),real和fake图片共享discriminator的参数
            batch_images = batch_images * 2 - 1

            # generator的输入噪声
            batch_noise = np.random.uniform(-1, 1, size=(batch_size, noise_size))
            # 从一个均匀分布[low,high)中随机采样,此处为[-1,1），采样大小为（64，100）

            # Run optimizers
            _ = sess.run(d_train_opt, feed_dict={real_img: batch_images, noise_img: batch_noise})
            _ = sess.run(g_train_opt, feed_dict={noise_img: batch_noise})

        # 每一轮结束计算loss
        train_loss_d = sess.run(d_loss,
                                feed_dict={real_img: batch_images,
                                           noise_img: batch_noise})
        # real img loss
        train_loss_d_real = sess.run(d_loss_real,
                                     feed_dict={real_img: batch_images,
                                                noise_img: batch_noise})
        # fake img loss
        train_loss_d_fake = sess.run(d_loss_fake,
                                     feed_dict={real_img: batch_images,
                                                noise_img: batch_noise})
        # generator loss
        train_loss_g = sess.run(g_loss,
                                feed_dict={noise_img: batch_noise})

        print("Epoch {}/{}...".format(e + 1, epochs),
              "Discriminator Loss: {:.4f}(Real: {:.4f} + Fake: {:.4f})...".format(train_loss_d, train_loss_d_real,
                                                                                  train_loss_d_fake),
              "Generator Loss: {:.4f}".format(train_loss_g))
        # 记录各类loss值
        losses.append((train_loss_d, train_loss_d_real, train_loss_d_fake, train_loss_g))  # 列表增加各类损失值

        # 抽取样本后期进行观察
        sample_noise = np.random.uniform(-1, 1, size=(n_sample, noise_size))
        # 从一个均匀分布[low,high)中随机采样,此处为[-1,1），采样大小为（25，100）

        gen_samples = sess.run(get_generator(noise_img, g_units, img_size, reuse=True),
                               feed_dict={noise_img: sample_noise})
        samples.append(gen_samples)

        # 存储checkpoints
        saver.save(sess, './checkpoints/generator.ckpt')

# 将sample的生成数据记录下来
with open('train_samples1.pkl', 'wb') as f:
    pickle.dump(samples, f)  # 以序列化的形式将samples写入到train_samples.pkl文件中


# 将losses列表 转换为losses数组 并保存losses数组
losses = np.array(losses)  # losses列表转化losses为矩阵
np.save('losses.npy', losses)






